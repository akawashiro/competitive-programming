#include <stdio.h>
#include <deque>
#include <string.h>
#include <limits.h>
#include <iostream>
#include <queue>

using namespace std;

int k,w,h;
int mv[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int dist[210][210][210];
int filled[210][210];
int D[200+1][200+1][4];
int cache[210][210][210];

class Q
{
	public:
		int c,x,y;
		/*bool operator<(const Q q)
			const{
				return c>q.c;
			}*/
};

bool operator<(const Q q,const Q r)
{
	return q.c>r.c;
}

int rec(int x,int y,int o)
{
	//printf("rec x=%d y=%d o=%d c=%d\n",x,y,o,dist[x][y][o]);

	int &r=cache[x][y][o];
	if(r!=-1)
		;
	else if(x==0 && y==0 && o==0)
		r=1;
	else if(x==w-1 && y==h-1 && o<k-1)
		r=0;
	else if(x==0 && y==0 && 0<o)
		r=0;
	else
	{
		r=0;
		for(int i=0;i<4;i++)
			if(D[x][y][i]!=0)
			{
				int xx=x+mv[i][0],yy=y+mv[i][1];
				int cc=dist[x][y][o]-D[x][y][i];
				//printf("xx=%d yy=%d cc=%d\n",xx,yy,cc);
				int oo,bo=0,ce=k-1;
				while(1<ce-bo)
				{
					int me=(bo+ce)/2;
					if(dist[xx][yy][me]<cc)
						bo=me;
					else
						ce=me;
				}
				if(dist[xx][yy][bo]==cc)
					r+=rec(xx,yy,bo);
				else if(dist[xx][yy][ce]==cc)
					r+=rec(xx,yy,ce);
				else
					;
				/*for(oo=0;oo<k;oo++)	//二部探索が必要
					if(dist[xx][yy][oo]==cc)
						break;
				if(oo<k)
					r+=rec(xx,yy,oo);*/
			}
	}
	return r;
}

void solve(int _h,int _w,int _k,int _D[200+1][200+1][4],int *ans_len,int *ans_num)
{
	//printf("solve()-start\n");

	k=_k,w=_w,h=_h;
	h++,w++;
	for(int p=0;p<201;p++)
		for(int q=0;q<201;q++)
			for(int r=0;r<4;r++)
				D[p][q][r]=_D[p][q][r];

	for(int i=0;i<210;i++)
		for(int j=0;j<210;j++)
		{
			for(int k=0;k<210;k++)
				dist[i][j][k]=INT_MAX;
			filled[i][j]=0;
		}

	priority_queue<Q> que;
	Q q;
	q.c=0,q.x=0,q.y=0;
	que.push(q);

	while(!que.empty())
	{
		int c=que.top().c,x=que.top().x,y=que.top().y;

		//printf("c=%d x=%d y=%d\n",c,x,y);
		
		que.pop();
		if(filled[x][y]==k ||
			 	(0<filled[x][y] && dist[x][y][filled[x][y]-1]==c))
			;
		else
		{
			dist[x][y][filled[x][y]]=c;
			//printf("dist[%d][%d][%d]=%d\n",x,y,filled[x][y],c);
			filled[x][y]++;
			if(x!=w-1 || y!=h-1)
				for(int i=0;i<4;i++)
					if(D[x][y][i]!=0)
					{
						q.c=c+D[x][y][i];
						q.x=x+mv[i][0];
						q.y=y+mv[i][1];
						/*if(q.x<0 || q.y<0 || w<=q.x || h<=q.y)
						{
							//printf("er1 x=%d y=%d i=%d\n",x,y,i);
							//printf("er1 D[%d][%d][%d]=%d\n",x,y,i,D[x][y][i]);
						}*/
						if(!(filled[q.x][q.y]==k || (0<filled[q.x][q.y] && dist[q.x][q.y][filled[q.x][q.y]-1]==q.c)))
							que.push(q);
					}
		}
	}

	memset(cache,-1,sizeof(cache));
	//printf("dist[%d][%d][%d]=%d\n",w-1,h-1,k-1,dist[w-1][h-1][k-1]);
	int kCost=dist[w-1][h-1][k-1];
	int kWay=rec(w-1,h-1,k-1);
	//printf("kCost=%d kWay=%d\n",kCost,kWay);

	*ans_len=kCost;
	*ans_num=kWay;
	
	//printf("solve()-end\n");
}
