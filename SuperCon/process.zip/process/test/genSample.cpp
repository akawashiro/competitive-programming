#include <stdio.h>
#include <stdlib.h>

int e()
{
	return 1;
}

int main()
{
	int h,w,k;
	perror("w=");
	scanf("%d",&w);
	perror("h=");
	scanf("%d",&h);
	perror("k=");
	scanf("%d",&k);

	if(200<w || 200<h || 200<k)
		printf("(w,h,k)<=200\n");
	else
	{
		printf("%d, %d, %d\n",w,h,k);
		for(int i=0;i<h+1;i++)
		{
			for(int j=0;j<w-1;j++)
				printf("%d, ",e());
			printf("%d\n",e());
		}
		for(int i=0;i<w+1;i++)
		{
			for(int j=0;j<h-1;j++)
				printf("%d, ",e());
			printf("%d\n",e());
		}
	}
	return 0;
}

