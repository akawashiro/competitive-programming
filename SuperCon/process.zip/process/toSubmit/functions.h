void solve(int n,int m,int k,int D[200+1][200+1][4],int *ans_len,int *ans_num);
void heapPop(int*,int*,int*);
void heapPush(int,int,int);
int heapEmpty();

