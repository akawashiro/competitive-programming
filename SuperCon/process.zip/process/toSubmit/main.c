#include <stdio.h>
//#include <deque>
#include <string.h>
#include <limits.h>
//#include <iostream>
//#include <queue>
#include "functions.h"

//using namespace std;

int k,w,h;
int mv[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int dist[210][210][210];
int filled[210][210];
int D[200+1][200+1][4];
int cache[210][210][210];

void heapPop(int*,int*,int*);
void heapPush(int,int,int);
int heapEmpty();

/*
class Q
{
	public:
		int c,x,y;
		bool operator<(const Q q)
			//const{
			//	return c>q.c;
			//}
};

bool operator<(const Q q,const Q r)
{
	return q.c>r.c;
}*/


int rec(int x,int y,int o)
{
	int pp;
	//printf("rec x=%d y=%d o=%d c=%d\n",x,y,o,dist[x][y][o]);

	int *r=&cache[x][y][o];
	if(*r!=-1)
		;
	else if(x==0 && y==0 && o==0)
		*r=1;
	/*else if(x==w-1 && y==h-1 && o<k-1)
		*r=0;
	else if(x==0 && y==0 && 0<o)
		*r=0;*/
	else
	{
		*r=0;
		for(pp=0;pp<4;pp++)
			if(D[x][y][pp]!=0)
			{
				int xx=x+mv[pp][0],yy=y+mv[pp][1];
				int cc=dist[x][y][o]-D[x][y][pp];
				//printf("xx=%d yy=%d cc=%d\n",xx,yy,cc);
				int bo=0,ce=k-1;
				while(1<ce-bo)
				{
					int me=(bo+ce)/2;
					if(dist[xx][yy][me]<cc)
						bo=me;
					else
						ce=me;
				}
				if(dist[xx][yy][bo]==cc)
					*r+=rec(xx,yy,bo);
				else if(dist[xx][yy][ce]==cc)
					*r+=rec(xx,yy,ce);
				else
					;
				/*for(oo=0;oo<k;oo++)	//二部探索が必要
					if(dist[xx][yy][oo]==cc)
						break;
				if(oo<k)
					r+=rec(xx,yy,oo);*/
			}
	}
	return *r;
}

void solve(int _h,int _w,int _k,int _D[200+1][200+1][4],int *ans_len,int *ans_num)
{
	int pp,qq,rr;
	int c,x,y;
	int cc,xx,yy;

	//printf("solve()-start\n");
	//fflush(stdout);

	k=_k,w=_w,h=_h;
	h++,w++;

	//printf("solve()-varialbes-initation-first-start\n");
	//fflush(stdout);

	for(pp=0;pp<201;pp++)
		for(qq=0;qq<201;qq++)
			for(rr=0;rr<4;rr++)
				D[pp][qq][rr]=_D[pp][qq][rr];

	//printf("solve()-varialbes-initation-first-end\n");
	//fflush(stdout);

	for(pp=0;pp<210;pp++)
		for(qq=0;qq<210;qq++)
		{
			for(rr=0;rr<210;rr++)
				dist[pp][qq][rr]=INT_MAX;
			filled[pp][qq]=0;
		}

	//printf("solve()-varialbes-initation-end\n");
	//fflush(stdout);

	/*priority_queue<Q> que;
	Q q;
	q.c=0,q.x=0,q.y=0;
	que.push(q);*/
	heapPush(0,0,0);

	while(!heapEmpty())
	{
		//int c=que.top().c,x=que.top().x,y=que.top().y;
		heapPop(&c,&x,&y);

		//printf("c=%d x=%d y=%d\n",c,x,y);
		//fflush(stdout);
		
		//que.pop();
		if(filled[x][y]==k ||
			 	(0<filled[x][y] && dist[x][y][filled[x][y]-1]==c))
		{
			//printf("branch-end\n");
			//fflush(stdout);
			;
		}
		else
		{
			//printf("not-branch-end\n");
			//fflush(stdout);

			dist[x][y][filled[x][y]]=c;
			filled[x][y]++;

			//printf("not-branch-end-2\n");
			//fflush(stdout);

			/*if((x==0 && y==0 && 0<c) || (x==w-1 && y==h-1))
				continue;*/
			//printf("dist[%d][%d][%d]=%d\n",x,y,filled[x][y],c);
			if(x!=w-1 || y!=h-1)
				for(pp=0;pp<4;pp++)
					if(D[x][y][pp]!=0)
					{

						//printf("not-branch-end-3-pp=%d\n",pp);
						//fflush(stdout);

						cc=c+D[x][y][pp];
						xx=x+mv[pp][0];
						yy=y+mv[pp][1];


						//printf("not-branch-end-3-pp=%d-2\n",pp);
						//fflush(stdout);
						
						/*if(q.x<0 || q.y<0 || w<=q.x || h<=q.y)
						{
							//printf("er1 x=%d y=%d i=%d\n",x,y,i);
							//printf("er1 D[%d][%d][%d]=%d\n",x,y,i,D[x][y][i]);
						}*/
						if(!(filled[xx][yy]==k || (0<filled[xx][yy] && dist[xx][yy][filled[xx][yy]-1]==cc)))
						{

							//printf("not-branch-end-3-pp=%d-3\n",pp);
							//fflush(stdout);

							heapPush(cc,xx,yy);
						}

						//printf("not-branch-end-3-pp=%d-5\n",pp);
						//fflush(stdout);

					}
		}
	}

	//printf("stage-using-heap-end\n");

	memset(cache,-1,sizeof(cache));
	//printf("dist[%d][%d][%d]=%d\n",w-1,h-1,k-1,dist[w-1][h-1][k-1]);
	if(dist[w-1][h-1][k-1]!=INT_MAX)
	{
		*ans_len=dist[w-1][h-1][k-1];
		*ans_num=rec(w-1,h-1,k-1);
	}
	else
	{
		*ans_len=0;
		*ans_num=0;
	}
	//printf("kCost=%d kWay=%d\n",kCost,kWay);

	//*ans_len=kCost;
	//*ans_num=kWay;
	
	//printf("solve()-end\n");
}

