#include <stdio.h>

//#define HEAPTABLESIZE 14*210*210*210
#define HEAPTABLESIZE 4*210*210*210

int heapData[HEAPTABLESIZE];
int heapTable[HEAPTABLESIZE][3];
int heapSize=0;
int heapTableSize=HEAPTABLESIZE;
int heapTableCur=0;

void heapPop(int*,int*,int*);
void heapPush(int,int,int);
int heapEmpty();

void heapDown(int);
void heapUp(int);

int heapEmpty()
{
	return (heapSize==0);
}

void heapPop(int *c,int *x,int *y)
{
	if(heapSize==0)
	{
		*c=-1,*x=-1,*y=-1;
	}
	else if(heapSize==1)
	{
		int r=heapData[1];
		heapData[heapSize]=-1;
		heapSize=0;
		*c=heapTable[r][0],*x=heapTable[r][1],*y=heapTable[r][2];
	}
	else
	{
		int r=heapData[1];
		heapData[1]=heapData[heapSize];
		heapSize--;
		heapDown(1);
		*c=heapTable[r][0],*x=heapTable[r][1],*y=heapTable[r][2];
	}
}

void heapPush(int c,int x,int y)
{
	heapTableCur=(heapTableCur+1)%heapTableSize;
	heapTable[heapTableCur][0]=c;
	heapTable[heapTableCur][1]=x;
	heapTable[heapTableCur][2]=y;

	//printf("heapUp-Push-1\n");
	//fflush(stdout);

	heapSize++;
	heapData[heapSize]=heapTableCur;

	//printf("heapUp-dead\n");
	//fflush(stdout);

	heapUp(heapSize);
}

void heapUp(int k)
{
	int p=k/2;
	if(k==1)
		;
	else if(heapTable[heapData[k]][0]<heapTable[heapData[p]][0])
	{
		int t=heapData[k];
		heapData[k]=heapData[p];
		heapData[p]=t;
		heapUp(p);
	}
	else
		;
}

void heapDown(int k)
{
	int n1=2*k,n2=2*k+1;
	if(heapSize<n1)
	{
		;
	}
	else if(heapSize<n2)
	{
		if(heapTable[heapData[n1]][0]<heapTable[heapData[k]][0])
		{
			int t=heapData[k];
			heapData[k]=heapData[n1];
			heapData[n1]=t;
			heapDown(n1);
		}
		else
		{
			;
		}
	}
	else
	{
		if(heapTable[heapData[n1]][0]<heapTable[heapData[n2]][0] && 
				heapTable[heapData[n1]][0]<heapTable[heapData[k]][0])
		{
			int t=heapData[k];
			heapData[k]=heapData[n1];
			heapData[n1]=t;
			heapDown(n1);
		}
		else if(heapTable[heapData[n2]][0]<=heapTable[heapData[n1]][0] && 
				heapTable[heapData[n2]][0]<heapTable[heapData[k]][0])
		{
			int t=heapData[k];
			heapData[k]=heapData[n2];
			heapData[n2]=t;
			heapDown(n2);
		}
		else
		{
			;
		}
	}	
}

