#include <stdio.h> 
#include <stdlib.h>

void init();
int lay(int);

int n,k;
int layout[32767];

int main(int argc,char *argv[])
{
    n = atoi(argv[1]);
    k = atoi(argv[2]);

    init();

    printf("%d\n",lay(n));
}

void init()
{
    for(int i=0;i<32767;i++){
        layout[i] = -1;
    }
}

int lay(int n)
{
    if(layout[n] != -1){
        return layout[n];
    }else if(n == 1){
        return 1;
    }else if(n == 2){
        return 2;
    }else{
        layout[n] = lay(n-1)+lay(n-2);
        return layout[n];
    }
}
