#include <iostream>
using namespace std;

int connect(int strings[101][101],int connecetion)
{
		
