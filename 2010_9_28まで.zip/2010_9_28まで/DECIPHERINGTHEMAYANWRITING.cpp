#include <string>
#include <cstdio>
#include <iostream>
#include <queue>
using namespace std;

int g,s;
string W,S;
int spointer;
int word[256];
queue<char> target;
int counter=0;

int main()
{
		cin >> g >> s;
		cin >> W >> S;
		for(int i=0;i<W.size();i++)
				word[i]=0;
		for(int i=0;i<W.size();i++)
				word[W[i]]++;
		for(spointer=0;spointer<W.size()-1;spointer++){
				word[S[spointer]]--;
				target.push(S[spointer]);
				cout << spointer << endl;
				cout << word[S[spointer]] << endl;
				cout << "t" << target.size() << endl;
		}
		cout << endl;
		for(spointer;spointer<S.size();spointer++){
				word[S[spointer]]--;
				target.push(S[spointer]);

				bool flag=true;
				for(int i=0;i<256;i++){
						if(word[i] != 0){
								printf("i=%c\n",i);
								flag=false;
								break;
						}
				}
				if(flag)
						counter++;
				
				word[target.front()]++;
				target.pop();
				cout << spointer << endl;
				cout << word[S[spointer]] << endl;
				cout << "t" << target.size() << endl;
				cout << endl;
		}

		cout << counter << endl;
		return 0;
}
