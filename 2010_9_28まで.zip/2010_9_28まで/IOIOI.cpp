#include <string>
#include <iostream>
using namespace std;

int main()
{
		int n,m;
		string s;
		cin >> n;
		cin >> m;
		cin >> s;

		int series=0;
		int count=0;
		for(int i=0;i+2<s.size();i++){	
				if(s[i]=='I'&&s[i+1]=='O'&&s[i+2]=='I'){
						series++;
				}else if(s[i]=='O'&&s[i+1]=='I'&&s[i+2]=='O'){
				}else{
						if(n<=series)
								count+=series-n+1;
						series=0;
				}
		}
		if(n<=series)
				count+=series-n+1;

		cout << count << endl;
		return 0;
}
		
