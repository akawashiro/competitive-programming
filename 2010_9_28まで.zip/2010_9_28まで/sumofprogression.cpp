#include <iostream>
#include <fstream>
using namespace std;
int n,k;
int date[100000];

int main()
{
		ifstream ifs("input.txt");
		ifs >> n;
		ifs >> k;
		for(int i=0;i<n;i++){
				ifs >> date[i];
				//cout << "date[" << i << "]=" << date[i] << endl;
		}

		long firstsum=0;
		for(int i=0;i<k;i++){
				firstsum+=date[i];
		}
		//cout << "firstsum=" << firstsum << endl;

		for(int i=0;i<n-k;i++){
				int a=firstsum-date[i]+date[i+k];
				if(firstsum < a)
						firstsum=a;
		}

		cout << firstsum << endl;

		return 0;
}
