#include <cstdio>
#include <queue>
#include <iostream>
using namespace std;

#define SOUTH 0
#define WEST 1
#define EDGE 2
#define MAPSIZE 1001

struct POSITION{
		int x,y;
};

int map[MAPSIZE][MAPSIZE];
int number[MAPSIZE][MAPSIZE];
bool iscalled[MAPSIZE][MAPSIZE];
int H,W,N;

int main()
{
		cin >> H;
		cin >> W;
		cin >> N;
		for(int i=0;i<MAPSIZE;i++){
				for(int j=0;j<MAPSIZE;j++){
						map[i][j]=EDGE;
				}
		}
		for(int i=0;i<H;i++){
				for(int j=0;j<W;j++){
						int a;
						scanf("%d",&a);
						map[i][j]=a;
				}
		}
		for(int i=0;i<MAPSIZE;i++){
				for(int j=0;j<MAPSIZE;j++){
						number[i][j]=0;
						iscalled[i][j]=false;
				}
				
		}
		//cout << "input end" << endl;

		number[0][0]=(N-1);
		queue<POSITION> next;
		POSITION p;
		p.x=0;
		p.y=0;
		next.push(p);
		while(!next.empty()){
				int x=next.front().x;
				int y=next.front().y;
				next.pop();
				if(map[y][x]!=EDGE && !iscalled[y][x]){
						iscalled[y][x]=true;
						if(map[y][x]==WEST)
								number[y][x+1]+=(number[y][x]%2);
						else
								number[y+1][x]+=(number[y][x]%2);
						number[y][x+1]+=(number[y][x]/2);
						number[y+1][x]+=(number[y][x]/2);
						p.x=x+1;
						p.y=y;
						next.push(p);
						p.x=x;
						p.y=y+1;
						next.push(p);
				}
		}

		//cout << "Hei!!\n";
		for(int i=0;i<H;i++){
				for(int j=0;j<W;j++){
						//cout << number[i][j] << "-" << map[i][j] << " ";
				}
				//cout << endl;
		}
		//cout << endl;

		for(int i=0;i<H;i++){
				for(int j=0;j<W;j++){
						if(number[i][j]%2==1){
								//cout << "Hi!\n";
								if(map[i][j]==SOUTH){
										//cout << "Hei!\n";
										map[i][j]=WEST;
								}else if(map[i][j]==WEST){
										//cout << "Hoi!\n";
										map[i][j]=SOUTH;
								}
						}
				}
		}

		for(int i=0;i<H;i++){
				for(int j=0;j<W;j++){
						//cout << number[i][j] << "-" << map[i][j] << " ";
				}
				//cout << endl;
		}

		int x=0;
		int y=0;
		while(map[y][x]!=EDGE){
				if(map[y][x]==SOUTH)
						y++;
				else
						x++;
		}
		printf("%d %d\n",y+1,x+1);

		return 0;
}

