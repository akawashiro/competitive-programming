#include <stdio.h>

int date[11] = {0,21,34,1,9,11,23,90,77,8,6};

void swap(int i,int j)
{
	int k = date[i];
	date[i] = date[j];
	date[j] = k;
}


void qsort(int top,int last)
{
	if(last <= top) return;
	
	int pivot = (date[top]+date[last])/2;
	int left = top;
	int right = last;
	
	while(1){
		while(date[left]<pivot) left++;
		while(pivot<date[right]) right--;
	
		if(right <= left){
			qsort(top,--left);
			qsort(++right,last);
			break;
		}
		swap(left,right);
	}
}

int main()
{
	for(int i=1;i<=10;i++)
		printf("%d\n",date[i]);
	
	qsort(1,10);
	
	printf("-----------\n");
	
	for(int i=1;i<=10;i++)
		printf("%d\n",date[i]);
}
