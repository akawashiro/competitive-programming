#include <cstdio>

int main(){
		int n,m;
		int goal[101];
		for(int i=0;i<101;i++)
				goal[i]=0;
		FILE *ifp = fopen("input.txt","r");
		fscanf(ifp,"%d%d",&n,&m);

		for(int i=0;i<n;i++){
				for(int j=1;j<m+1;j++){
						int a;
						fscanf(ifp,"%d",&a);
						if(a)
								goal[j]++;
				}
		}

		int result[101];
		for(int i=0;i<101;i++)
				result[i]=i;

		bool ischange=true;
		while(ischange){
				ischange=false;
				for(int i=1;i<m;i++){
						if(goal[i]<goal[i+1]){
								ischange=true;
								int a;
								a=goal[i];
								goal[i]=goal[i+1];
								goal[i+1]=a;
								a=result[i];
								result[i]=result[i+1];
								result[i+1]=a;
						}
				}
		}

		for(int i=1;i<=m;i++)	
				printf("%d",result[i]);
		printf("\n");
								
		fclose(ifp);
		return 0;
}

		
