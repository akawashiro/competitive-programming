#include <iostream>
#include <cmath>

int nhumming = 0;

int forctorial(int a,int n)
{
    if(n == 0){
        std::cout << "n=0" << std::endl;
        return 1;
    }else if(n == 1){
        std::cout << "n=1" << std::endl;
        return a;
    }else{
        std::cout << "1<n" << std::endl;
        return (a*forctorial(a,n-1));
    }
}

int humming(int n,int m)
{
    int a,b,c;
    int i,j,k;
    
    i = 0;
    a = 0;
    while(i <= m){
        i = forctorial(2,a);
        j = i;
        a++;
        b = 0;
        while(j <= m){
            j = i*forctorial(3,b);
            k = j;
            b++;
            c = 0;
            while(k <= m){
                k = j*forctorial(5,c);
                c++;
                if(n<=k && k<=m){
                    nhumming++;
                }
            }
        }
    }
    
    return nhumming;
}


int main()
{
    std::cout << humming(1,86) << std::endl;
    return 0;
}
