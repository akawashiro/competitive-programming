#include <cstdio>
#include <iostream>
using namespace std;

char map[5][5];
float all;
float count;

void clean(int x,int y,int n)
{
		//printf("x=%d,y=%d,n=%d\n",x,y,n);

		if(n==0){
				if(map[x][y]==2){
						all++;
						count++;
						return;
				}else{
						all++;
						return;
				}
		}

		if(map[x+1][y]!=-1){
				clean(x+1,y,n-1);
		}else{
				clean(x,y,n-1);
		}
		if(map[x-1][y]!=-1){
				clean(x-1,y,n-1);
		}else{
				clean(x,y,n-1);
		}
		if(map[x][y+1]!=-1){
				clean(x,y+1,n-1);
		}else{
				clean(x,y,n-1);
		}
		if(map[x][y-1]!=-1){
				clean(x,y-1,n-1);
		}else{
				clean(x,y,n-1);
		}
}

int main()
{
		int n;
		cin >> n;
		while(n!=0){
				for(int i=0;i<5;i++){
						for(int j=0;j<5;j++){
								if(i==4 || j==4 || i==0 || j==0)
										map[i][j]=-1;
								else
										map[i][j]=0;
						}
				}
				char s,t,b;
				cin >> s >> t >> b;
				s-='A';	t-='A';	b-='A';
				//printf("s=%d,t=%d,b=%d\n",s,t,b);
				//int x=(t%3==0) ? 3 : t%3;
				map[t%3+1][t/3+1]=2;	
				//x=(b%3==0) ? 3 : b%3;
				map[b%3+1][b/3+1]=-1;

				/*for(int i=0;i<5;i++){
						for(int j=0;j<5;j++)
								printf("%d ",map[j][i]);
						cout << endl;
				}*/

				all=0;
				count=0;
				//x=(s%3==0) ? 3 : t%3;
				clean(s%3+1,s/3+1,n);				
				printf("%1.8f\n",count/all);

				//cout << count << " count\n";
				//cout << all << " all\n\n";

				cin >> n;
		}
		return 0;
}

