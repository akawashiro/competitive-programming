#include <fstream>
#include <iostream>
using namespace std;
int map[10000+1][10000+1];
int n;
int r;

void makemap()
{
		for(int i=0;i<10001;i++){
				for(int j=0;j<10001;j++){
						map[i][j]=0;
				}
		}

		ifstream ifs("input.txt");
		ifs >> n;
		ifs >> r;

		int x1,x2,y1,y2;
		for(int i=0;i<n;i++){
				ifs >> x1;
				ifs >> y1;
				ifs >> x2;
				ifs >> y2;
				for(int i=y1;i<y2;i++){
						for(int j=x1;j<x2;j++){
								//cout << "map["<<i<<"]["<<j<<"]" << endl;
								map[i][j]=1;
						}
				}
		}
}

int countarea()
{
		int a=0;
		for(int i=0;i<10001;i++){
				for(int j=0;j<10001;j++){
						if(map[i][j]==1){
								a++;
								//cout << "map["<<i<<"]["<<j<<"]" << endl;
						}
				}
		}
		return a;
}

int countline()
{
		int count=0;
		for(int i=0;i<10001;i++){
				for(int j=0;j<10000;j++){
						if(map[i][j]!=map[i][j+1])
								count++;
				}
		}
		for(int i=0;i<10000;i++){
				for(int j=0;j<10001;j++){
						if(map[i][j]!=map[i+1][j])
								count++;
				}
		}
		for(int i=0;i<10001;i++){
				if(map[0][i])
						count++;
				if(map[i][0])
						count++;
				if(map[10000][i])
						count++;
				if(map[i][10000])
						count++;
		}

		return count;
}

int main()
{
		makemap();

		int area=countarea();
		int line=countline();

		cout << "area=" << area << endl;
		cout << "line=" << line << endl;

		return 0;
}
