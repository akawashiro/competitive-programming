#include <iostream>
using namespace std;

int main()
{
		int d;
		while(cin >> d){
				int S=0;
				for(int i=d;i<=600;i+=d)
						S+=d*((i-d)*(i-d));
				cout << S << endl;
		}
		return 0;
}

