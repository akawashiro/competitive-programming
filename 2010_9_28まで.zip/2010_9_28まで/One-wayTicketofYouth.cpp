#include <iostream>
#include <map>
#include <limits.h>
using namespace std;

int ttime[101][101];
int tcost[101][101];
int nstation;

int min(int ,int,int[101][101]);
//int mintime(int ,int);

int main()
{
		for(int i=0;i<=100;i++){
				for(int j=0;j<=100;j++){
						if(i==j){
								ttime[i][j]=0;
								tcost[i][j]=0;
						}else{
								ttime[i][j]=INT_MAX;
								tcost[i][j]=INT_MAX;
						}
				}
		}
		int n;
		cin >> n >> nstation;
		for(int i=0;i<n;i++){
				int a,b,c,t;
				cin >> a >> b >> c >> t;
				tcost[a][b]=c; tcost[b][a]=c;
				ttime[a][b]=t; ttime[b][a]=t;
		}
		
		int k;
		cin >> k;
		for(int i=0;i<k;i++){
				int p,q,r;
				cin >> p >> q >> r;
				if(r==0)
						cout << min(p,q,tcost) << endl;
				else
						cout << min(p,q,ttime) << endl;
		}

		return 0;
}

int min(int start,int end,int table[101][101])
{
		map<int,int> station;
		station.insert(map<int,int>::value_type(0,start));
		while(1){
				int s=station.begin()->second;
				int c=station.begin()->first;
				table[start][s]=c;	table[s][start]=c;
				if(s==end)
						break;
				for(int i=0;i<=nstation;i++){
						if(i!=s && table[i][s]!=INT_MAX)
								station.insert(map<int,int>::value_type(c+table[i][s],i));
				}
				station.erase(station.begin());
		}
		return table[start][end];
}

/*int mintime(int start,int end)
{
		map<int,int> station;
		station.insert(map<int,int>::value_type(0,start));
		while(1){
				int s=station.begin()->second;
				int c=station.begin()->first;
				ttime[start][s]=c;	ttime[s][start]=c;
				if(s==end)
						break;
				for(int i=0;i<=nstation;i++){
						if(i!=s && ttime[i][s]!=INT_MAX)
								station.insert(map<int,int>::value_type(c+ttime[i][s],i));
				}
				station.erase(station.begin());
		}
		return ttime[start][end];
}*/
