#include <stdio.h>
#include <math.h>

int main()
{
		float a,b,c,d,e,f;
		while(6 == scanf("%f%f%f%f%f%f",&a,&b,&c,&d,&e,&f)){
				float x = (c*e-b*f)/(a*e-b*d);
				x*=1000;
				x+=0.5;
				x=floor(x);
				x/=1000;
				float y = (c*d-a*f)/(b*d-a*e);
				y*=1000;
				y+=0.5;
				y=floor(y);
				y/=1000;
				printf("%4.3f %4.3f\n",x,y);
		}
		return 0;
}
