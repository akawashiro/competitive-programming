#include <queue>
#include <stdio.h>

int a,b,c;
int N;
int result[300+1];
class EXAM{
	public:
		int i,j,k,r;
		EXAM & operator=(const EXAM & a){
				if(this == &a)
						return *this;
				i=a.i;j=a.j;k=a.k;r=a.r;
		}
};
std::queue<EXAM> exam;

int main()
{
	FILE *ifp;
	EXAM d;

	ifp = fopen("input.txt","r");
	fscanf(ifp,"%d %d %d",&a,&b,&c);
	printf("%d %d %d\n",a,b,c);
	fscanf(ifp,"%d",&N);
	printf("%d\n",N);

	for(int i=1;i<=300;i++){
			result[i] = 2;
	}

	for(int i=0;i<N;i++){
			fscanf(ifp,"%d %d %d %d",&(d.i),&(d.j),&(d.k),&(d.r));
			printf("%d %d %d %d\n",d.i,d.j,d.k,d.r);
			if(d.r == 0){
					exam.push(d);
					continue;
			}
			result[d.i]=1;result[d.j]=1;result[d.k]=1;
	}
	
	while(!exam.empty()){
			d = exam.front();
			exam.pop();
			if(result[d.i]==1 && result[d.j]==1 && result[d.k]==2)
					result[d.k]=0;
			if(result[d.i]==1 && result[d.j]==2 && result[d.k]==1)
					result[d.j]=0;		
			if(result[d.i]==2 && result[d.j]==1 && result[d.k]==1)
					result[d.i]=0;
	}
	
	for(int i=1;i<=a+b+c;i++){
			printf("%d\n",result[i]);
	}
}
