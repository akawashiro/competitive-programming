#include <iostream>
using namespace std;

int main()
{
		int n;
		cin >> n;
		while(n != 0){
				int A=0;
				int B=0;
				for(int i=0;i<n;i++){
						int a,b;
						cin >> a >> b;
						if(a < b){
								B+=(a+b);
						}else if(b < a){
								A+=(a+b);
						}else{
								A+=a;
								B+=b;
						}
				}
				cout << A << " " << B << endl;
				cin >> n;
		}
		return 0;
}

