#include <iostream>
using namespace std;

bool judge(int a,int b,int c){
		if(a*a==b*b+c*c || b*b==a*a+c*c || c*c==a*a+b*b)
				return true;
		else
				return false;
}

int main()
{
		int N;
		cin >> N;
		for(N;0<N;N--){
				int side[3];
				for(int i=0;i<3;i++)
						cin >> side[i];
				if(judge(side[0],side[1],side[2]))
						cout << "YES\n";
				else
						cout << "NO\n";
		}
		return 0;
}
