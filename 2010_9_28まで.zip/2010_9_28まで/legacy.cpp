#include <stdio.h>

char map[12][12];    //map[Y���W][X���W]

void initmap(FILE *ifp)
{
    for(int i=0;i<12;i++){
        for(int j=0;j<12;j++)
            map[i][j] = '-';
    }
    for(int i=1;i<11;i++){
        for(int j=1;j<11;j++){
            int c;
            c = fgetc(ifp);
            if(c == 0 || c == '\n')
                c = fgetc(ifp);
            map[i][j] = c;
        }
    }
}

void fillblock(int x,int y,char crop)
{
    printf("fillblock(%d,%d,%c)\n",x,y,crop);
    
    if(map[y][x] == crop){
        map[y][x] = '-';
        fillblock(x,y-1,crop);
        fillblock(x,y+1,crop);
        fillblock(x-1,y,crop);
        fillblock(x+1,y,crop);
    }
    else
        return;
}

void printmap()
{
    for(int i=1;i<11;i++){
        for(int j=1;j<11;j++){
            printf("%c",map[i][j]);
        }
        printf("\n");
    }
}

int countblock()
{
    int count = 0;
    for(int y=1;y<11;y++){
        for(int x=1;x<11;x++){
            if(map[y][x] != '-'){
                fillblock(x,y,map[y][x]);
                count++;
            }
        }
    }
    return count;
}

int main()
{
    FILE *ifp;
    ifp = fopen("input.txt","r");
    
    initmap(ifp);
    
    printmap();
    
    int result = countblock();
    
    printf("This map has %d blocks.",result);
    
    fclose(ifp);
    
    return 0;
}
