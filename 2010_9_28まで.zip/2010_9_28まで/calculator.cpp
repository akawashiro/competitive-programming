//made on 6/1

#include <stack>
#include <list>
#include <stdio.h>

class PHRAISE{
public:
    bool isnumber;
    int value;
    
    PHRAISE operator=(const PHRAISE &p2){
        if(this == &p2) return *this;
        isnumber = p2.isnumber;
        value =p2.value;
        return *this;
    }
};

enum STATE { START,END,LEFTBRACE,RIGHTBRACE,NUMBER,OPERATOR };

FILE *ifp;
std::list<PHRAISE> formula;

PHRAISE getphraise()    //戻り値 'e'でEOF
{
    PHRAISE p;
    char c;
    
    if(feof(ifp)){
        p.isnumber = false;
        p.value = 'e';
        
        return p;
    }
    c = fgetc(ifp);
    if(('0'<=c) && (c<='9')){
        p.isnumber = true;
        p.value = c-48;
        
        //printf("number in getphraise\n");
    }
    else{
        p.isnumber = false;
        p.value = c;
    }
    
    if(p.isnumber)
        printf("phraise = %d\n",p.value);
    else
        printf("phraise = %c\n",p.value);
    
    return p;
}

void decompose()    //式の間違いチェックしてない
{
    enum STATE state = START;
    PHRAISE p;
    bool flag = true;
    std::list<PHRAISE> o;
    
    while(flag){
        p = getphraise();
        switch(state)
        {
        case START:
                if(p.isnumber){
                    formula.push_back(p);
                    state = OPERATOR;
                }
                else if(p.value == '('){
                    //printf("(\n");
                    
                    state = OPERATOR;
                    decompose();
                }
            break;
        case NUMBER:
                if(p.isnumber){
                    formula.push_back(p);
                    state = OPERATOR;
                }
                else if(p.value == 'e'){
                    printf("p.value == 'e'\n");
                    
                    while(!o.empty()){
                        formula.push_back(o.back());
                        o.pop_back();
                    }
                    flag = false;
                }
                else if(p.value == '('){
                    //printf("(\n");
                    
                    state = OPERATOR;
                    decompose();
                }
            break;
        case RIGHTBRACE:
        case LEFTBRACE:
        case OPERATOR:
                if(p.value == '+' || p.value == '-'){
                    if((!o.empty()) && (o.back().value == '*' || o.back().value == '/')){
                        formula.push_back(o.back());
                        o.pop_back();
                    }
                    o.push_back(p);
                    state = NUMBER;
                }
                else if(p.value == '*' || p.value == '/'){
                    if((!o.empty()) && (o.back().value == '*' || o.back().value == '/')){
                        formula.push_back(o.back());
                        o.pop_back();
                    }
                    o.push_back(p);
                    state = NUMBER;
                }
                else if(p.value == ')'){
                    while(!o.empty()){
                        formula.push_back(o.back());
                        o.pop_back();
                    }
                    state = OPERATOR;
                    flag = false;
                }
                else if(p.value == 'e'){
                    printf("p.value == 'e'\n");
                    
                    while(!o.empty()){
                        formula.push_back(o.back());
                        o.pop_back();
                    }
                    
                    printf("loop end\n");
                    
                    return;
                    
                    printf("flag = false\n");
                }
            break;
        }
    }
    
    printf("decompose end\n");
}

int compute()
{
    printf("compute\n");
    
    std::list<PHRAISE>::iterator i;
    std::stack<int> s;
    
    i = formula.begin();
    while(i != formula.end()){
        if(i->isnumber)
            printf("%d ",i->value);
        else
            printf("%c ",i->value);
        i++;
    }
    printf("\n");
    
    i = formula.begin();
    while(i != formula.end()){
        if(i->isnumber){
            s.push(i->value);
        }
        else{
            int tmp1,tmp2;
            tmp1 = s.top();
            s.pop();
            tmp2 = s.top();
            s.pop();
            
            switch(i->value){
            case '*':
                s.push(tmp1*tmp2);
                break;
            case '/':
                s.push(tmp2/tmp1);
                break;
            case '+':
                s.push(tmp1+tmp2);
                break;
            case '-':
                s.push(tmp1-tmp2);
                break;
            }
        }
        i++;
    }
    
    return s.top();
}


int main()
{
    ifp = fopen("input.txt","r");
    
    decompose();
    
    printf("中間\n");
    
    int result = compute();
    
    printf("%d\n",result);
    
    return 0;
}
