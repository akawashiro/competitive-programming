//made on 5/31

#include <fstream>
#include <iostream>

char pattern[8][8];

void turn()
{
    char temp[8][8];
    
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            temp[8-1-i][j] = pattern[j][i];
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            pattern[i][j] = temp[i][j];
}

int main()
{
    std::ifstream ifs( "input.txt" );
    
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            char c;
            ifs >> c;
            if(c == '\n')
                ifs >> c;
            pattern[j][i] = c;
        }
    }
    
    turn();
    
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            std::cout << pattern[j][i];
        }
        std::cout << std::endl;
    }
    
    std::cout << std::endl;
    
    turn();
    
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            std::cout << pattern[j][i];
        }
        std::cout << std::endl;
    }
    
    return 0;
}
