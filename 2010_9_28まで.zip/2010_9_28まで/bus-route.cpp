#include <stdio.h>
#include <list>
#include <iostream>

int main()
{
    int busstop[15] = {0,1,2,3,4,5,6,7,8,9,5,4,3,2,1};
    int start = 4;
    int end = 2;
    std::list<int> ans;
    
    int i=0;
    while(1){
        if(busstop[i] == start)
            break;
        i++;
        if(i==15)
            i=0;
    }
    while(1){
        ans.push_back(busstop[i]);
        
        if(busstop[i] == start)
            ans.clear();
        else if(busstop[i] == end)
            break;
        
        i++;
        if(i==15)
            i=0;
    }
    
    ans.push_front(start);
    
    std::list<int>::iterator j = ans.begin();
    while(j != ans.end()){
        printf("%d ",*j);
        j++;
    }
}
