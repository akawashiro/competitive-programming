#include <stdio.h>
#include <stdlib.h>

int map[101][101];
int memo[4][101][101];
int w,h;

void init();
int fillmap(int,int,bool,bool);
void show();

int main(int argc,char **argv)
{
		int result;
		w = atoi(argv[1])-1;
		h = atoi(argv[2])-1;
		

		init();

		result = (fillmap(0,1,false,false)+fillmap(1,0,false,true))%100000;

		printf("%d\n",result);

		return 0;
}

void init()
{
		for(int k=0;k<4;k++){
			for(int i=0;i<101;i++){
				for(int j=0;j<101;j++){
						memo[k][i][j] = -1;
				}
			}
		}

		for(int i=0;i<101;i++){
				for(int j=0;j<101;j++){
						map[i][j] = -1;
				}
		}


		for(int i=0;i<w+1;i++){
				for(int j=0;j<h+1;j++){
						map[i][j] = 0;
				}
		}

		map[0][0] = 1;
}

int fillmap(int x,int y,bool isturned,bool isright)
{
		//printf("fillmap(%d,%d)\n",x,y);

		int result;
		
		if(memo[isturned+2*isright][x][y] != -1)
			   return memo[isturned+2*isright][x][y];

		if(map[x][y] == -1)
				result = 0;
		else if(x == w && y == h)
				result = 1;
		else if(isturned){
				if(isright)
						result = (fillmap(x+1,y,false,true))%100000;
				else if(!isright)
						result = (fillmap(x,y+1,false,false))%100000;
		}
		else if(!isturned){
				if(isright)
						result = (fillmap(x+1,y,false,true)+fillmap(x,y+1,true,false))%100000;
				else if(!isright)
						result = (fillmap(x+1,y,true,true)+fillmap(x,y+1,false,false))%100000;
		}

		memo[isturned+2*isright][x][y] = result;

		return result;
}

void show()
{
		printf("%d\n",map[w][h]);
}
