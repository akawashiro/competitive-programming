#include <stdio.h>
#include <stdlib.h>

int middle_square(int i)
{
	i *= i;
	i /= 100;
	i %= 10000;
	
	return i;
}

int main(int argc, char *argv[])
{
	int s = atoi(argv[1]);
	
	for(int i=0; i<10; i++){
		s = middle_square(s);
		printf("%04d\n",s);
	}
}
