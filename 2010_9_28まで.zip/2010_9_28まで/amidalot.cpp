struct stick{
		int nright,nleft;
		int height;
};

int main()
{

