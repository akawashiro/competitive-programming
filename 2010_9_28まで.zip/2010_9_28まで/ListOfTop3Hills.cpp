#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

int main()
{
		vector<int> hill;
		for(int i=0;i<10;i++){
				int a;
				cin >> a;
				hill.push_back(a);
		}
		sort(hill.begin(),hill.end(),greater<int>());
		cout << hill[0] << endl;
		cout << hill[1] << endl;
		cout << hill[2] << endl;
		return 0;
}
