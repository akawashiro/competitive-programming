#include <iostream>
#include <cstdio>
using namespace std;

int main(){
		int n;
		//cin >> n;

		cout << 'a';

		int ispillar[5001][5001];
		/*int pillarx[3000];
		int pillary[3000];
		int max=0;
		for(int i=0;i<=5000;i++){
				for(int j=0;j<=5000;j++){
						ispillar[i][j]=false;
				}
		}

		cout << "b";

		for(int i=0;i<n;i++){
				int x,y;
				cin >> x >> y;
				ispillar[x][y]=true;
				pillarx[i]=x;
				pillary[i]=y;
		}

		cout << "c";

		for(int i=0;i<n;i++){
				for(int j=0;j<n;j++){
						if(i==j)
								continue;
						int a=pillarx[i]-pillarx[j];
						int b=pillary[i]-pillary[j];
						int c=pillarx[i];
						int d=pillary[j];
						if(ispillar[c+b][d-a] && ispillar[c+a+b][d+b-a]){
								if(max < c*c+d*d)
										max = c*c+d*d;
						}
				}
		}
		cout << max << endl;*/

		return 0;
}

