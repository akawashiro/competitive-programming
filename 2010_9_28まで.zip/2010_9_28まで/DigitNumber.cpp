#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
		int a,b;
		while(scanf("%d%d",&a,&b) == 2){
				int c=10;
				int i=1;
				while(c <= a+b){
					i++;
					c*=10;
				}
				cout << i << endl;
		}
		return 0;
}
