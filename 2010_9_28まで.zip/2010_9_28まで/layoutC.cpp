#include <stdlib.h>
#include <stdio.h>

int layoutA[32767+1];
int layoutB[32767+1][3];

void init();
int layA(int);
int layB(int);

int main(int argc,char *argv[])
{
    int m = atoi(argv[1]);
    int n = atoi(argv[2]);
    int k = atoi(argv[3]);

    init();

    int result = layA(n)*layB(m)+layA(n-1)*layoutB[m][2];
    
    printf("%d\n",result);

    return 0;
}

void init()
{
    for(int i=0;i<=32767+1;i++){
        layoutA[i] = -1;
    }
    layoutA[1] = 1;
    layoutA[2] = 2;

    for(int i=0;i<=32767+1;i++){
        for(int j=0;j<3;j++){
            layoutB[i][j] = -1;
        }
    }
    layoutB[1][1] = 1;
    layoutB[2][0] = 3;
    layoutB[2][2] = 1;
 
}

int layA(int n)
{
    for(int i=3;i<=n;i++){
        layoutA[i] = layoutA[i-1]+layoutA[i-2];
    }
    return layoutA[n];
}

int layB(int n)
{
    for(int i=3;i<n+1;i++){
        for(int j=0;j<3;j++){
            if((i*3+j) % 2 == 1){   //敷き詰められないなら飛ばす
                continue;
            }else if(j == 0){
                layoutB[i][j] = layoutB[i-2][0]*3 + layoutB[i-2][2]*2;
            }else if(j == 1){
                layoutB[i][j] = layoutB[i-1][0] + layoutB[i-1][2];
            }else if(j == 2){
                layoutB[i][j] = layoutB[i-1][1];
            }
        }
    }

    return layoutB[n][0];
}
