#include <stdio.h>
#include <math.h>

char map[10000][10];
char cmap[10000][10];
int R;
int C;

void copymap();
int count();

int main()
{
	FILE *ifp;
	ifp = fopen("input.txt","r");
	int r; int c;
	fscanf(ifp,"%d %d",&r,&c);
	R = r; C = c;
	for(int i=0;i<R;i++){
		for(int j=0;j<C;j++){
			int a;
			fscanf(ifp,"%d",&a);
			map[j][i] = a;
			cmap[j][i] = a;
		}
	}
	fclose(ifp);
	
	int re = count();
	printf("%d\n",re);
	
	return 0;
}

void copymap()
{
	for(int i=0;i<C;i++){
		for(int j=0;j<R;j++){
			cmap[i][j] = map[i][j];
		}
	}
}

int count()
{
	int count = 0;
	
	//printf("pow((double)2,%d) = %d\n",R,'(int)pow((double)2,(double)R));
			
	for(int i=0;i<4;i++){
		copymap();

		for(int j=0;j<C;j++){
			for(int k=0;k<R;k++){
				int a = ((i>>k) & 1) ? 1 : 0;
				if(a == 1){
					//cmap[j][k] = (cmap[j][k] == 1) ? 0 : 1;
					if(cmap[j][k] == 1)
						cmap[j][k] = 0;
					else
						cmap[j][k] = 1;
				}
			}
		}

		
		int a=0;	
		for(int j=0;j<C;j++){
			int b = 0;
			for(int k=0;k<R;k++){
				if(map[j][k] == 1)
					b++;
			}
			//b = (b<(R-b)) ? (R-b) : b;
			if(b < R-b)
				b = R-b;
			a += b;
		}
		printf("i=%d count=%d\n",i,a);
		if(count < a){
			count = a;
		}
	}

	return count;
}

