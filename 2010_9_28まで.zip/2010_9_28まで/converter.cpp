#include <iostream>
//#include <stdio.h>
#include <sstream>
#include <string>
#include <fstream>
//#include <stdlib.h>

using namespace std;

string convert(string s){
		stringstream t;
		t.str("");
		int number;
		int series;

		number=s[0];
		series=1;
		for(int i=1;i<s.size();i++){
				if(number==s[i])
						series++;
				else{
						t << series;
						t << number-48;
						series=1;
						number=s[i];
				}
		}
		t << series;
		t << number-48;
		
		//cout << t.str() << endl;
		return t.str();
}
				

int main(int argc,char *argv[]){
		int i;
		string s;
		
		//char *cs;
		//FILE *ifp=fopen("input.txt","r");
		//fscanf(ifp,"%d\n",&i);
		//printf("1");
		//fgets(cs,100,ifp);
		
		ifstream ifs("input.txt");
		ifs >> i;
		ifs >> s;

		//cout << "first" << s << endl;

		//s = (string)cs;

		for(int j=0;j<i;j++){
				s = convert(s);
				//cout << "j=" << j << s << endl;
		}

		cout << s << endl;

		//fclose(ifp);
		return 0;
}

