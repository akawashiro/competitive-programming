#include <iostream>
#include <cstdio>
using namespace std;

int height,width;
int cx,cy;

int search(int x,int y,int map[12][12])
{
		map[y][x]=3;
		printf("search(%d,%d,....)\n",x,y);
		for(int i=1;i<=height;i++){
				for(int j=1;j<=width;j++){
						cout << map[i][j] ;
				}
				cout << endl;
		}
		int handc=0;
		for(int i=1;i<=height;i++){
				for(int j=1;j<=width;j++){
						if(map[i][j]==1 || map[i][j]==2)
								handc++;
				}
		}
		if(handc==0){
				printf("end\n");
				return 1;
		}
		if(map[cx][cy]==3)
				return 0;

		int count=0;
		int i=1;
		while(x+i<=width){
				if(map[y][x+i]==1 || map[y][x+i]==2)	
						count+=search(x+i,y,map);
				i++;
		}
		i=1;
		while(1<=x-i){
				if(map[y][x-i]==1 || map[y][x-i]==2)	
						count+=search(x-i,y,map);
				i++;
		}
		i=1;	
		while(y+i<=height){
				if(map[y+i][x]==1 || map[y+i][x]==2)	
						count+=search(x,y+i,map);
				i++;
		}
		i=1;
		while(1<=y-i){
				if(map[y-i][x]==1 || map[y-i][x]==2)	
						count+=search(x,y-i,map);
				i++;
		}

		return count;
}
int main()
{
		int map[12][12];
		for(int i=0;i<12;i++){
				for(int j=0;j<12;j++){
						map[i][j]=3;
				}
		}
		cin >> width >> height;
		for(int i=1;i<=height;i++){
				for(int j=1;j<=width;j++){
						cin >> map[i][j];
						if(map[i][j]==2){
								cx=j;	cy=i;
								cout << "cx=" << cx << " cy=" << cy << endl;
						}
				}
		}	
		
		int i=1;
		int count=0;
		while(cx+i<=width){
				if(map[cy][cx+i]==1 || map[cy][cx+i]==2)	
						count+=search(cx+i,cy,map);
				i++;
		}
		i=1;
		while(1<=cx-i){
				if(map[cy][cx-i]==1 || map[cy][cx-i]==2)	
						count+=search(cx-i,cy,map);
				i++;
		}
		i=1;	
		while(cy+i<=height){
				if(map[cy+i][cx]==1 || map[cy+i][cx]==2)	
						count+=search(cx,cy+i,map);
				i++;
		}
		i=1;
		while(1<=cy-i){
				if(map[cy-i][cx]==1 || map[cy-i][cx]==2)	
						count+=search(cx,cy-i,map);
				i++;
		}

		cout << count << endl;

		return 0;
}

