#include <stdlib.h>
#include <stdio.h>

void init();
int lay(int);

int layout[32767+1][3];

int main(int argc,char *argv[])
{
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);
    if(n%2 == 1){
        printf("nは偶数でなければなりません\n");
        return 0;
    }
    
    init();

    printf("%d\n",lay(n));

    return 0;
}

void init()
{
    for(int i=0;i<32767;i++){
        for(int j=0;j<3;j++){
            layout[i][j] = -1;
        }
    }

    layout[1][1] = 1;
    layout[2][0] = 3;
    layout[2][2] = 1;
}

int lay(int n) //動的計画法使用
{
    for(int i=3;i<n+1;i++){
        for(int j=0;j<3;j++){
            if((i*3+j) % 2 == 1){   //敷き詰められないなら飛ばす
                continue;
            }else if(j == 0){
                layout[i][j] = layout[i-2][0]*3 + layout[i-2][2]*2;
            }else if(j == 1){
                layout[i][j] = layout[i-1][0] + layout[i-1][2];
            }else if(j == 2){
                layout[i][j] = layout[i-1][1];
            }
        }
    }

    return layout[n][0];
}
