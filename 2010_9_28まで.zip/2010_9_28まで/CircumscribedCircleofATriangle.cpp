#include <iostream>
#include <math.h>
#include <cstdio>
using namespace std;

int main()
{
		int n;
		cin >> n;
		for(n;0<n;n--){
				float x1,x2,x3,y1,y2,y3,a,b,c,d,e,f,xp,yp,r;
				cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
				a = x2-x1;
				b = y2-y1;
				c = (y2-y1)*(y2+y1)/2+(x2-x1)*(x2+x1)/2;
				d = x3-x1;
				e = y3-y1;
				f = (y3-y1)*(y3+y1)/2+(x3-x1)*(x3+x1)/2;
				xp = (c*e-b*f)/(a*e-b*d);
				yp = (c*d-a*f)/(b*d-a*e);
				r = sqrt((x1-xp)*(x1-xp)+(y1-yp)*(y1-yp));
				printf("%4.3f %4.3f %4.3f\n",xp,yp,r);
		}
		return 0;
}
