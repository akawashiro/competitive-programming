#include <fstream>
#include <iostream>
using namespace std;

struct SERIES{
		int number;
		bool isblack;
};

int main()
{
		int n;
		fstream ifs("input.txt");
		ifs >> n;
		SERIES l,ll;
		ll.number=0;
		l.number=1;
		ifs >> l.isblack;
		n--;
		int nwhite=0;
		for(int i=0;i<n;i++){
				bool isblack;
				ifs >> isblack;
				if(i%2==1 && isblack==l.isblack){
						l.number++;
				}else if(i%2==1 && isblack!=l.isblack){
						if(!ll.isblack){
								nwhite+=ll.number;
						}
						ll.number=l.number;
						ll.isblack=l.isblack;
						l.number=1;
						l.isblack=isblack;
				}else if(i%2==0 && isblack==l.isblack){
						l.number++;
				}else if(i%2==0 && isblack!=l.isblack){
						l.number+=ll.number;
						l.number++;
						l.isblack=ll.isblack;
						ll.number=0;
				}
		}
		if(!l.isblack)
				nwhite+=l.number;
		if(!ll.isblack)
				nwhite+=ll.number;

		cout << nwhite << endl;

		return 0;
}

								
