#include <iostream>
#include <stack>
using namespace std;

int main()
{
		int n;
		stack<int> rail;
		while(cin >> n){
				if(n == 0){
						cout << rail.top() << endl;
						rail.pop();
				}else{
						rail.push(n);
				}
		}
		return 0;
}

