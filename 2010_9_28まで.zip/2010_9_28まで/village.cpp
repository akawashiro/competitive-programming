#include <fstream>
#include <iostream>
using namespace std;
int n;
char map[5000+1][5000+1];
struct POINT{
		int x,y;
};
POINT pillar[3000];

int maxsquare();

int main()
{
		for(int i=0;i<5000+1;i++){
				for(int j=0;j<5000+1;j++){
						map[i][j]=false;
				}
		}
		ifstream ifs("input.txt");	
		ifs >> n;
		for(int i=0;i<n;i++){
				int x,y;
				ifs >> x;
				ifs >> y;
				pillar[i].x=x;
				pillar[i].y=y;
				map[y][x]=true;
		}
		
		int max=maxsquare();
		cout << max << endl;

		return 0;
}

int maxsquare()
{
		int max=0;
		for(int i=1;i<5001;i++){
				for(int j=1;j<5001;j++){
						for(int k=0;k<n;k++){
								if(!(pillar[k].y+i+j<5001 && pillar[k].y+j<5001
															&& 0<=pillar[k].x-i))
										continue;
								if(map[pillar[k].y][pillar[k].x] && map[pillar[k].y+i][pillar[k].x+j]
												&& map[pillar[k].y+i+j][pillar[k].x+j-i]
												&& map[pillar[k].y+j][pillar[k].x-i]){
										int a=i*i+j*j;
										if(max < a)
												max=a;
								}
						}
				}
		}
		return max;
}
