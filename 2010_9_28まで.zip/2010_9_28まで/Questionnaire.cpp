#include <iostream>
using namespace std;

int main()
{
		int place[101];
		int n,m;
		cin >> n >> m;
		while(n!=0 || m!=0){
				for(int i=1;i<=m;i++)
						place[i]=0;
				for(int i=0;i<n;i++){
						for(int j=1;j<=m;j++){
								int a;
								cin >> a;
								if(a == 1)
										place[j]++;
						}
				}
				for(int i=0;i<m;i++){
						int max=-1;
						int nmax=0;
						for(int j=1;j<=m;j++){
								if(max < place[j]){
										max=place[j];
										nmax=j;
								}
						}
						place[nmax]=-1;
						cout << nmax <<  " ";
				}
				cout << endl;
				cin >> n >> m;
		}
		return 0;
}
