#include <vector>
#include <bitset>
#include <fstream>
#include <iostream>
#include <iterator>
using namespace std;

int n,k;
bitset<100000+1> card;
vector<int> series;

void convert()
{
		cout << "convert() ";

		for(int i=1;i<=n;i++){
				int a=1;
				while(card[i]==card[i+1] && i<=n){
						i++;
						a++;
				}
				series.push_back(a);
				cout << a << " ";
		}

		cout << endl;
}

int max()
{
		int max=0;
		int parity=1;
		if(card[1])
				parity=0;
		if(!card[0]){
				for(int i=0;i!=series.size();i++){
						if(i%2==parity && max<series[i])
								max=series[i];
				}
		}else{
				cout << "card[0] is seted" << endl;
				for(int i=0;i!=series.size();i++){
						if(i%2==parity && max<=series[i]+1){
								cout << "max=series[" << i << "]+1" << endl;
								max=series[i]+1;
						}
				}
				for(int i=1;i!=series.size();i++){
						if(i%2!=parity && series[i]==1 && max<=series[i-1]+series[i+1]){
								cout << "max=series[" << i-1 << "]+series[" << i+1 << "]" << endl;
								max=series[i-1]+series[i+1]+1;
						}
				}
		}
		cout << "series[6]=" << series[6] << endl;
		return max;
}


int main()
{
		ifstream ifs("input.txt");
		ifs >> n;
		ifs >> k;
		for(int i=0;i<k;i++){
				int a;
				ifs >> a;
				card.set(a);
				cout << "set" << a << endl;
		}

		convert();
		int r=max();
		cout << "result=" << r << endl;

		return 0;
}
