#include <sstream>
#include <iostream>
using namespace std;

int main()
{
		int n;
		string s;
		cin >> n;
		while(n!=0){
				stringstream ss;
				cin >> s;
				for(int i=0;i<n;i++){
						char before=s[0];
						int num=1;
						for(int j=1;j<s.size();j++){
								if(s[j] == before){
										num++;
								}else{
										ss << num << before;
										before=s[j];
										num=1;
								}
						}
						ss << num << before;
						s=ss.str();
						ss.str("");
				}
				cout << s << endl;
				cin >> n;
		}
		return 0;
}

