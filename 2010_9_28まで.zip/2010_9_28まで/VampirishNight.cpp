#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
		int N,K;
		int blood[100];
		cin >> N >> K;
		while(N!=0 || K!=0){
				for(int i=0;i<K;i++)
						cin >> blood[i];
				for(int i=0;i<N;i++){
						for(int j=0;j<K;j++){
								int a;
								cin >> a;
								blood[j]-=a;
						}
				}
				for(int i=0;i<K;i++){
						if(blood[i] < 0){
								cout << "No" << endl;
								goto b1;
						}
				}
				cout << "Yes" << endl;
b1:				cin >> N >> K;
		}
		return 0;
}
