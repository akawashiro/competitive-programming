#include <iostream>
using namespace std;

int main()
{
		int i;
		cin >> i;
		while(i!=0){
				bool isouted=false;
				for(i;0<i;i--){
						int a,b,c;
						cin >> a;
						cin >> b;
						cin >> c;
						if(1000000 <= b*c){
								isouted=true;
								cout << a << endl;
						}
				}
				if(!isouted)
						cout << "NA" << endl;
				cin >> i;
		}
		return 0;
}
