#include <list>
#include <vector>
#include <fstream>
#include <iostream>
using namespace std;
class SERIES{
		public:
				int first;
				int number;
				SERIES & operator=(const SERIES &sr)
				{
						if(this == &sr)
								return *this;
						first=sr.first;
						number=sr.number;
				}
};
list<SERIES> card;
int n,m;
int p,q,r;

void divide(int x);
void replace(int x,int y);
void show();
void output();

int main()
{
		ifstream ifs("input.txt");
		ifs >> n;
		ifs >> m;
		ifs >> p;
		ifs >> q;
		ifs >> r;
		SERIES sr;
		sr.first=1;
		sr.number=n;
		card.push_back(sr);
		
		int x,y;
		cout << "n=" << n << " m=" << m  << " p=" << p << " q=" << q << " r=" << r << endl;
		//for(int i=0;i<m;i++)
		//		cout << i << endl;
		for(int i=0;i!=m;i++){
				//cout << "i=" << i << endl;
				
				//output();

				ifs >> x;
				ifs >> y;
				divide(x);
				
				//output();
				
				divide(y);
				
				//output();
				
				replace(x,y);
				
				//output();

				//show();
		}
		show();

		return 0;
}

void divide(int x)
{
		//cout << "divide(" << x << ")" << endl;

		list<SERIES>::iterator it=card.begin();
		while(it->number < x){
				x-=it->number;
				it++;
		}
		SERIES sr;
		sr.first=it->first+x;
		sr.number=it->number-x;
		it->number=x;
		it++;
		card.insert(it,sr);
}

void replace(int x,int y)
{
		//cout << "replace(" << x << "," << y << ")" << endl;

		list<SERIES> sr1;
		list<SERIES> sr2;
		list<SERIES> sr3;
		list<SERIES>::iterator it=card.begin();
		int a=0;
		while(a+it->number <= x){
				a+=it->number;
				sr3.push_back(*it);
				it++;
		}
		while(a+it->number <= y){
				a+=it->number;
				sr2.push_back(*it);
				it++;
		}
		while(it != card.end()){
				sr1.push_back(*it);
				it++;
		}
		//sr1.merge(sr2);
		//sr2.merge(sr3);
		for(it=sr2.begin();it!=sr2.end();it++)
				sr1.push_back(*it);
		for(it=sr3.begin();it!=sr3.end();it++)
				sr1.push_back(*it);
		card=sr1;
}

void output()
{
		cout << "output() ";
		list<SERIES>::iterator it=card.begin();
		for(it;it!=card.end();it++)
				cout << " " << it->first << " " << it->number;
		cout << endl;
}

void show()
{
		cout << "show()" << endl;

		list<SERIES>::iterator it=card.begin();
		int result=0;
		p--;
		divide(p);
		divide(q);
		//output();
		while(0 <= p-it->number){
				p-=it->number;
				q-=it->number;
				
				//cout << it->first << " " << it->number << endl;
				
				it++;
		}
		cout << endl;
		while(0 <= q-it->number){
				q-=it->number;

				//cout << it->first << " " << it->number << endl;
				
				for(int i=0;i<it->number;i++){
						//cout << i+it->first << endl;
						if(i+it->first <= r)
								result++;
				}
				it++;
		}

		cout << endl << result << endl;
}				

