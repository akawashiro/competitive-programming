#include <cstdio>
#include <stack>

int n,M;
int a,b;
std::stack<int> tray[2][3];
int cost1;
int cost2;

void startfigure();
bool canmove(int,int,int);
void move(int,int,int);
int getcost(int,int,int);

int main()
{
    FILE *ifp;
    ifp = fopen("input.txt","r");
    
    fscanf(ifp,"%d %d",&a,&b);    

    fscanf(ifp,"%d %d",&n,&M);
    printf("1");
    for(int i=0;i<3;i++){
        int j;
        fscanf(ifp,"%d",&j);
        printf("1");  
        for(j;0<j;j--){
            int a;
            fscanf(ifp,"%d",&a);
            tray[0][i].push(a);
            tray[1][i].push(a);
        }
    }

    printf("1");

    startfigure();

    int cost = (cost1 < cost2) ? cost1 : cost2;
    printf("%d\n",cost);

    fclose(ifp);

    return 0;
}

void startfigure()
{
    if(canmove(0,0,1)){
        move(0,0,1);
        cost1 = getcost(0,0,1);
    }else if(canmove(0,1,0)){
        move(0,1,0);
        cost1 = getcost(0,1,0);
    }else if(canmove(0,1,2)){
        move(0,1,2);
        cost1 = getcost(0,1,2);
    }else if(canmove(0,2,1)){
        move(0,2,1);
        cost1 = getcost(0,2,1);
    }else{;}

    if(canmove(1,0,1)){
        cost2 = getcost(1,tray[1][0].top(),false);
    }else if(canmove(1,1,0)){
        cost2 = getcost(1,tray[1][1].top(),true);
    }else if(canmove(1,1,2)){
        cost2 = getcost(1,tray[1][1].top(),false);
    }else if(canmove(1,2,1)){
        cost2 = getcost(1,tray[1][2].top(),true);
    }else{;}
}

int getcost(int t,int t1,int t2)
{
    int count = 1;
    int bt1,bt2;
    bt1 = t1; bt2 = t2;

    for(int i=0;i<M;i++){
        if(canmove(t,0,1) && (bt1 != 1 || bt2 != 0)){
            move(t,0,1);
            bt1 = 0; bt2 = 1;
        }else if(canmove(t,1,0) && (bt1 != 0 || bt2 != 1)){
            move(t,0,1);
            bt1 = 1; bt2 = 0;
        }else if(canmove(t,1,2) && (bt1 != 2 || bt2 != 1)){
            move(t,1,2);
            bt1 = 1; bt2 = 2;
        }else if(canmove(t,2,1) && (bt1 != 1 || bt2 != 2)){
            move(t,2,1);
            bt1 = 2; bt2 = 1;
        }
        count++;
        if((tray[t][0].empty() && tray[t][1].empty()) || (tray[t][1].empty() && tray[t][2].empty()))
            return count;
    }
    return -1;
}

bool canmove(int t,int t1,int t2)
{
    if(tray[t][t1].empty())
        return false;
    else if(!tray[t][t1].empty() && tray[t][t2].empty())
        return true;
    else if(tray[t][t1].empty() && tray[t][t2].empty())
        return false;
    else if(tray[t][t1].top() > tray[t][t2].top())
        return true;
    else
        return false;
}

void move(int t,int t1,int t2)
{
    tray[t][t2].push(tray[t][t1].top());
    tray[t][t1].pop();
}
