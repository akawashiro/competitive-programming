#include <iostream>
#include <vector>
using namespace std;

class POSITION{
		public:
				int x,y;
};

#define OFFICESIZE 502

int office1[OFFICESIZE][OFFICESIZE];
bool isseached1[OFFICESIZE][OFFICESIZE];
int office2[OFFICESIZE][OFFICESIZE];
bool isseached2[OFFICESIZE][OFFICESIZE];
int R;
int W1,H1,X1,Y1;
int W2,H2,X2,Y2;

int main()
{
		cin >> R;
		for(int i=0;i<OFFICESIZE;i++){
				for(int j=0;j<OFFICESIZE;j++){
						office1[i][j]=-1;
						isseached1[i][j]=false;
						office2[i][j]=-1;
						isseached2[i][j]=false;
				}
		}
		cin >> W1;
		cin >> H1;
		cin >> X1;
		cin >> Y1;
		for(int i=1;i<=H1;i++){
				for(int j=1;j<=W1;j++){
						cin >> office1[i][j];
				}
		}
		cin >> W2;
		cin >> H2;
		cin >> X2;
		cin >> Y2;
		for(int i=1;i<=H2;i++){
				for(int j=1;j<=W2;j++){
						cin >> office2[i][j];
				}
		}
		cout << "heo\n" ;

		int count1=0;
		int count2=0;
		int level1=0;
		int level2=0;
		vector<POSITION> next1,next2;
		POSITION p;
		p.x=X1;p.y=Y1;
		isseached1[p.y][p.x]=true;
		next1.push_back(p);
		p.x=X2;p.y=Y2;
		isseached2[p.y][p.x]=true;
		next2.push_back(p);
		while(count1 <= R || count2 <= R){
				if(count1 <= R){
					level1++;
					for(int i=0;i<next1.size();i++){
							int x,y;
							x=next1[i].x;
							y=next1[i].y;
							if(office1[y][x] <= level1){
									count1++;
									office1[y][x]=-1;
									p.x=x+1;p.y=y;
									if(!isseached1[p.y][p.x]){
										isseached1[p.y][p.x]=true;
										next1.push_back(p);
									}
									p.x=x-1;p.y=y;
									if(!isseached1[p.y][p.x]){
										isseached1[p.y][p.x]=true;
										next1.push_back(p);
									}
									p.x=x;p.y=y+1;
									if(!isseached1[p.y][p.x]){
										isseached1[p.y][p.x]=true;
										next1.push_back(p);
									}
									p.x=x;p.y=y-1;
									if(!isseached1[p.y][p.x]){
										isseached1[p.y][p.x]=true;
										next1.push_back(p);
									}
							}
					}
				}
				if(count2 <= R){
						level2++;
						for(int i=0;i<next2.size();i++){
								int x,y;
								x=next2[i].x;
								y=next2[i].y;
								if(office2[y][x] <= level2){
										count2++;
										office2[y][x]=-1;
										p.x=x+1;p.y=y;
										if(!isseached2[p.y][p.x]){
											isseached2[p.y][p.x]=true;
											next2.push_back(p);
										}
										p.x=x-1;p.y=y;
										if(!isseached2[p.y][p.x]){
											isseached2[p.y][p.x]=true;
											next2.push_back(p);
										}
										p.x=x;p.y=y+1;
										if(!isseached2[p.y][p.x]){
											isseached2[p.y][p.x]=true;
											next2.push_back(p);
										}
										p.x=x;p.y=y-1;
										if(!isseached2[p.y][p.x]){
											isseached2[p.y][p.x]=true;
											next2.push_back(p);
										}
								}
						}
				}
		}

		cout << level1+level2 << endl;
		return 0;
}
