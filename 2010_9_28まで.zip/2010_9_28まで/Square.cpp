#include <iostream>
#include <vector>
using namespace std;

vector<int> v;

void square(int rest,int limit)
{
		if(rest==0){
				for(int i=0;i<v.size();i++)
						cout << v[i] << " ";
				cout << endl;
		}
		for(int i=rest;1<=i;i--){
				if(i<=limit){
						v.push_back(i);
						square(rest-i,i);
						v.pop_back();
				}
		}
}

int main()
{
		int n;
		cin >> n;
		while(n!=0){
				square(n,n+1);
				cin >> n;
		}
		return 0;
}

