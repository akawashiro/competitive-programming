#include <stdio.h>
#include <iostream>
using namespace std;

void swap(int *a,int *b)
{
		int c=*a;
		*a=*b;
		*b=c;
}

int GCD(int x,int y)
{
		if(x < y)
				swap(&x,&y);
		while(x != y){
				x=x-y;
				if(x < y)
						swap(&x,&y);
		}
		return x;
}

int main()
{
		int a,b;
		while(2 == scanf("%d%d",&a,&b))
				cout << GCD(a,b) << " " << a/GCD(a,b)*b << endl;
		return 0;
}
