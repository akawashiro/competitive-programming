#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

int main()
{
		vector<int> mark;
		ifstream ifs("input.txt");
		int N,M;
		ifs >> N;
		ifs >> M;
		for(int i=0;i<N;i++){
				int a;
				ifs >> a;
				mark.push_back(a);
		}
		sort(mark.begin(),mark.end());

		long long point[M+1];
		long long lastpoint[M+1];
		for(int i=0;i<=M;i++)
				lastpoint[i]=0;
		for(int i=0;i<N;i++){
				for(int j=0;j<M+1;j++){
						if(mark[i] <= j)
								point[j]=mark[i]+point[j-mark[i]];
						else
								point[j]=lastpoint[j];
				}
				for(int j=0;j<=M;j++)
						lastpoint[j]=point[j];
		}

		cout << point[M] << endl;

		return 0;
}

