#include <iostream>
#include <string>
#include <cstdio>
using namespace std;

int main()
{
		int N;
		cin >> N;
		for(int i=0;i<N;i++){
				string s1,s2;
				cin >> s1 >> s2;
				if(80 < s1.size() || 80 < s2.size()){
						cout << "overflow" << endl;
						continue;
				}
				char el1[80];	char el2[80];
				for(int i=0;i<80;i++){
						el1[i]=0;	el2[i]=0;
				}
				for(int i=s1.size()-1;0<=i;i--)
						el1[i]=s1[s1.size()-1-i]-48;
				
				/*cout << endl;
				for(int i=79;0<=i;i--){
						if(el1[i]!=0)
								printf("%d",el1[i]);
				}
				cout << endl;*/

				for(int i=s2.size()-1;0<=i;i--)
						el2[i]=s2[s2.size()-1-i]-48;
				bool overflow=false;
				for(int i=0;i<80;i++){
						if(overflow){
								el1[i]++;
								overflow=false;
						}
						el1[i]+=el2[i];
						if(9 < el1[i]){
								el1[i]-=10;
								overflow=true;
						}
				}
				if(overflow){
						cout << "overflow" << endl;
						continue;
				}
				int j=79;
				while(el1[j]==0)
						j--;
				for(j;0<=j;j--)
						printf("%d",el1[j]);
				cout << endl;
		}
		return 0;
}

