#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
		int w,n;
		int stick[31];
		for(int i=0;i<32;i++)
				stick[i]=i;

		cin >> w >> n;
		
		for(n;0<n;n--){
				int a,b;
				scanf("%d,%d",&a,&b);
				int c=stick[a];
				stick[a]=stick[b];
				stick[b]=c;
		}

		for(int i=1;i<=w;i++)
				cout << stick[i] << endl;

		return 0;
}
