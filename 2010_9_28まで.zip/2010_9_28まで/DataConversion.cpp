#include <iostream>
using namespace std;

int main()
{
		int n;
		cin >> n;
		while(n != 0){
				char table[256];
				for(int i=0;i<256;i++)
						table[i]=i;
				for(int i=0;i<n;i++){
						char a,b;
						cin >> a >> b;
						table[a]=b;
				}
				int m;
				cin >> m;
				for(int i=0;i<m;i++){
						char a;
						cin >> a;
						cout << table[a];
				}
				cout << endl;
				cin >> n;
		}
		return 0;
}

