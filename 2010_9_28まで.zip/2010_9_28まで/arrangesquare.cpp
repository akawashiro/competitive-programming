#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;
void arrange(int before,int total,string s)
{
		//cout << "arrange(" << before << "," << total << "," << s << ")" << endl;
		if(total==0){
				cout << s << endl;
				return;
		}
		for(int i=before;1<=i;i--){
				if(i <= total){
						stringstream ss;
						ss << s << i << " ";
						arrange(i,total-i,ss.str());
				}
		}
}
int main()
{
		ifstream ifs("input.txt");
		int n;
		ifs >> n;
		arrange(n,n,"");
		return 0;
}
