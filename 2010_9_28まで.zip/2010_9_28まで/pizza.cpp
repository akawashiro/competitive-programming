#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
		int n,d,m;
		vector<int> store;
		cin >> d;
		cin >> n;
		cin >> m;
		store.push_back(0);
		store.push_back(d);
		for(int i=0;i<n-1;i++){
				int a;
				cin >> a;
				store.push_back(a);
		}
		sort(store.begin(),store.end());

		int answer=0;
		for(int i=0;i<m;i++){
				int a;
				int min;
				cin >> a;
				for(int j=0;j+1<store.size();j++){
						if(store[j]<=a && a<=store[j+1]){
								if(a-store[j] < store[j+1]-a)
										min=a-store[j];
								else
										min=store[j+1]-a;
						}
				}
				answer+=min;
		}
		cout << answer << endl;
		return 0;
}

