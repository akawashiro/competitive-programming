#include <math.h>
#include <iostream>
using namespace std;

int main()
{
		int x=100000;
		int n;
		cin >> n;
		for(n;0<n;n--){
				x=x*105/100;
				if(x%1000 != 0){
						x-=x%1000;
						x+=1000;
				}
		}
		cout << x << endl;
		return 0;
}
