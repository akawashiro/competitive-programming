#include <stdio.h>
#define MAX 1000000

int main()
{
		bool isPrime[MAX];
		for(int i=0;i<MAX;i++)
				isPrime[i]=true;
		isPrime[0]=false;
		isPrime[1]=false;
		for(int i=0;i<MAX;i++){
				if(isPrime[i]){
						int j=2;
						while(j*i<MAX){
								isPrime[j*i]=false;
								j++;
						}
				}	
		}

		int n;
		while(1 == scanf("%d",&n)){
				int count=0;
				for(int i=0;i<=n;i++){
						if(isPrime[i])
								count++;
				}
				printf("%d\n",count);
		}

		return 0;
}

