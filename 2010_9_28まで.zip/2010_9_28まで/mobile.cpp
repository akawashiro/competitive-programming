int lcm(int a,int b)
{
		if(a<b)
				return lcm(b,a);
		else if(a==b)
				return a;
		else
				return lcm(b,a-b);
}
