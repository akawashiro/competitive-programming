#include <iostream>
using namespace std;

int atable[100];
int btable[100];
int n;

int search(bool isvisted[100],int last,int connection);

int main()
{
		cin >> n;
		while(n!=0){
				cout << "n=" << n << endl;
				for(int i=0;i<n;i++){
						int a,b;
						cin >> a >> b;
						cout << "a=" << a << "  b=" << b << endl;
						atable[i]=a;
						btable[i]=b;
				}
				bool isvisted[100];
				for(int i=0;i<n;i++)
						isvisted[i]=false;
				int max=0;
				for(int i=0;i<n;i++){
						int a,b;
						isvisted[i]=true;
						a=search(isvisted,atable[i],0);
						b=search(isvisted,btable[i],0);
						isvisted[i]=false;
						if(max < a)
								max = a;
						if(max < b)
								max = b;
				}
				cout << max << endl;
				cin >> n;
		}
		return 0;
}

int search(bool isvisted[100],int last,int connection)
{
		int max=connection;
		for(int i=0;i<n;i++){
				if(atable[i]==last && !isvisted[i]){
						int a;
						isvisted[i]=true;
						a = search(isvisted,btable[i],connection+1);
						if(max < a)
								max = a;
						isvisted[i]=false;
				}
				if(btable[i]==last && !isvisted[i]){
						int a;
						isvisted[i]=true;
						a = search(isvisted,atable[i],connection+1);
						if(max < a)
								max = a;
						isvisted[i]=false;
				}
		}
		return max;
}
