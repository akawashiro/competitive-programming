#include <iostream>
#include <cstdio>
#include <stack>
using namespace std;

stack<int> first[3];

int check(stack<int> state[3])
{
		int c=0;
		int before=-1;
		while(1){
				printf("0=%d,1=%d,2=%d\n",state[0].size(),state[1].size(),state[2].size());
				if(state[0]==first[0] && state[1]==first[1]
								&& state[2]==first[2])
						break;

				if(state[0].top() > state[1].top() && before != 2){
						state[1].push(state[0].top());
						state[0].pop();
						before=1;
						cout << "0to1\n";
				}else if(state[1].top() > state[0].top() && before != 1){
						state[0].push(state[1].top());
						state[1].pop();
						before=2;
						cout << "1to0\n";
				}else if(state[1].top() > state[2].top() && before != 4){
						state[2].push(state[1].top());
						state[1].pop();
						before=3;
						cout << "1to2\n";
				}else if(state[2].top() > state[1].top() && before != 3){
						state[1].push(state[2].top());
						state[2].pop();
						before=4;
						cout << "2to1\n";
				}
				c++;
		}
		return c;
}

int main()
{
		int n,m;
		cin >> n >> m;
		while(!(n == 0 && m == 0)){
				for(int i=0;i<3;i++){
						while(!first[i].empty())
								first[i].pop();
						first[i].push(0);
						for(int j=0;j<n;j++){
								int a;
								cin >> a;
								for(int k=0;k<a;k++){
										int b;
										cin >> b;
										first[i].push(b);
								}
						}
				}
				stack<int> state[3];
				state[0].push(0); state[1].push(0);	state[2].push(0);
				for(int i=1;i<=n;i++)
						state[0].push(i);
				cout << "a" << endl;
				int a1=check(state);
				while(!state[0].empty())
						state[0].pop();
				while(!state[1].empty())
						state[1].pop();
				while(!state[2].empty())
						state[2].pop();
				state[0].push(0); state[1].push(0);	state[2].push(0);
				for(int i=1;i<=n;i++)
						state[2].push(i);
				int a2=check(state);
				if(a1<a2 && a1<m)
						cout << a1 << endl;
				else if(a2<m)
						cout << a2 << endl;
				cin >> n >> m;
		}
		cout << "-1";
		return 0;
}

