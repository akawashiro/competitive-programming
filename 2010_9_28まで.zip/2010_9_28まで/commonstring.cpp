#include <string>
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
		ifstream ifs("input.txt");
		string s1,s2;
		int max=0;

		ifs >> s1;
		ifs >> s2;
		for(int i=0;i<s1.size();i++){
				for(int j=0;j<s2.size();j++){
						if(s1[i] == s2[j]){
								int a=1;
								while(s1[i+a] == s2[j+a] && i+a<s1.size() && j+a<s2.size())
										a++;
								if(max < a)
										max =a;
						}
				}
		}

		cout << max << endl;

		return 0;
}
