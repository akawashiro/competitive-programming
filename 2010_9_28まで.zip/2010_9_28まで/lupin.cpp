#include <cstdio>
#include <limits.h>
#include <float.h>

struct LIST{
    int storenumber,weight;  //storenumber はstoreのnumberとは違ってstore["storenumber"]で使う
    float time;
    LIST *before;
};

struct STORE{
    int position,number,weight;
};

int nstore;
LIST list[1<<15][15];
STORE store[15];

void init()
{
    FILE *ifp;
    
    printf("\ninit()\n");
    
    ifp = fopen("input.txt","r");
    fscanf(ifp,"%d\n",&nstore);
    
    printf("store = %d\n",nstore);
    
    for(int i=0;i<nstore;i++){
        fscanf(ifp,"%d %d %d\n",&store[i].number,&store[i].position,&store[i].weight);
        store[i].weight *= 20;
        
        printf("store[%d] = {%d %d %d}\n",i,store[i].number,store[i].position,store[i].weight);
        
    }
    fclose(ifp);
    for(int i=0;i<(1<<15);i++){
        for(int j=0;j<15;j++){
            list[i][j].time = 99999999;
            list[i][j].storenumber = j;
            list[i][j].before = NULL;
        }
    }
    for(int i=0;i<nstore;i++){
        list[1<<i][i].time = 0;
        list[1<<i][i].weight = store[i].weight;
        list[1<<i][i].time = 0;
    }
}

float gettime(LIST l,STORE s)   //lからsに行く時間
{
    float tmp = (store[l.storenumber].position-s.position)*(70+l.weight)/2000;
    if(tmp < 0)
        tmp *= -1;
    tmp += l.time;
    
    printf("\ngettime() = %f",tmp);
    
    
    return tmp;
}

void filllist()
{
    
    printf("\nfilllist()\n");
    
    for(short i=0;i<(1<<nstore);i++){
        for(int m=0;m<nstore;m++){
            if(i == (1<<m)){
                i++;
                break;
            }
        }
        for(int j=0;j<nstore;j++){
            
            printf("\n");
            
            short l = (i^(1<<j));
             for(int k=0;k<nstore;k++){
                if( ((l&(1<<k)) == 0) || (l == 0) ){
                    continue;
                }
                else{
                    float tmp = gettime(list[l][k],store[j]);
                    if(tmp < list[i][j].time){
                        list[i][j].time = tmp;
                        list[i][j].weight = list[l][k].weight + store[j].weight;
                        list[i][j].before = &list[l][k];
                        
                        printf("\nlist[%x][%d] = {weight=%d,time=%f,before=%x}",i,j,list[i][j].weight,list[i][j].time,list[i][j].before);
                        
                    }
                }
            }
        }
    }
}

void show()
{
    
    printf("\n\nshow()\n");
    
    LIST *end;
    for(int i=0;i<nstore-1;i++){
        if(list[(1<<nstore)-1][i].time < list[(1<<nstore)-1][i+1].time)
            end = &list[(1<<nstore)-1][i];
        else
            end = &list[(1<<nstore)-1][i+1];
    }
    while(end != NULL){
        printf("%d ",store[end->storenumber].number);
        end = end->before;
    }
    
    printf("\n");
    
}


int main()
{
    init();
    
    filllist();
    
    show();
    
    return 0;
}
