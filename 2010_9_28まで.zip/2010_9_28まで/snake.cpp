#include <stdio.h>

char statemachine(char *str){
	
    int neck = 0;
    char state = 'X';
	
    
    while(1){
	switch(state)
	{
	case 'X':
	    if(*str == '>') 
	        state = 'A';
	    else
	        return 'N';
	    break;
	case 'A':
	    str++;
	    if(*str == '\'')    
	        state = 'B';
	    else if(*str == '^') 
	        state = 'H';
	    else
	        return '5';
	    break;
	case 'B':
	    str++;
	    if(*str == '=')
	        state = 'C';
	    else
	        return '4';
	    break;
	case 'C':
	    str++;
	    if(*str == '=')
	        neck++;
	    else if(*str == '#')
	        state = 'D';
	    else
	        return '3';
	    break;
	case 'D':
	    str++;
	    if(*str == '=')
	        state = 'E';
	    else
	        return '2';
	    break;
	case 'E':
	    str++;
	    printf("neck = %d\n",neck);
	    if(*str == '=' && 0 < neck)
	        neck--;
	    else if(*str == '~' && 0 == neck)
	        state = 'F';
	    else
	        return '1';
	    break;
	case 'F':
	    str++;
	    if(*str == 0)
	        return 'A';
	    else
	        return 'N';
	    break;
	case 'H':
	    str++;
	    if(*str == 'Q')
	        state = 'I';
	    else
	        return 'N';
	    break;
	case 'I':
	    str++;
	    if(*str == '=')
	        state = 'J';
	    else
	        return 'N';
	case 'J':
	    str++;
	    if(*str == '~')
	        state = 'K';
	    else if(*str == 'Q')
	        state = 'I';
	    else
	        return 'N';
	    break;
	case 'K':
	    str++;
	    if(*str == '~')
	        state = 'L';
	    break;
	case 'L':
	    str++;
	    if(*str == 0)
	        return 'B';
	    else
	        return 'N';
	    break;
	}
    }
}

int main(int argc, char *argv[])
{
    printf("%c\n",statemachine(">'=====#=====~"));
    return 0;
}
