#include <cstdio>
#include <stdlib.h>
#include <list>
#include <queue>
#include <algorithm>

int A,B,K;
int cost[200000];   //添字が状態（Ⅰの数）を表す

void init();
void search();
void show();

int main(int argc,char *argv[])
{
    A = atoi(argv[1]);
    B = atoi(argv[2]);
    K = atoi(argv[3]);
    if(A+B<=K){
        printf("Cannot because A+B<=K\n");
        return 0;
    }

    init();

    search();

    show();

    return 0;
}

void init()
{
    for(int i=0;i<200000;i++){
        cost[i] = -1;
    }
}

void overturn(int none,std::list<int>& result)   //状態noneが変化しうるすべての場合を返す
{
    int nzero = A+B-none;
    
    for(int i=1;i<=K;i++){
        if(i<=nzero && K-i<=none){
            result.push_back(none+i-(K-i));
        }
    }
}

void search()
{
    std::list<int> nextobject;
    int depth;

    nextobject.push_back(B);
    depth = 0;
    while(0<nextobject.size()){
        cost[nextobject.front()] = depth;
        std::list<int> l;
        overturn(nextobject.front(),l);
        nextobject.pop_front();
        std::copy(l.begin(),l.end(),back_inserter(nextobject));
        std::list<int>::iterator it;
        depth++;
    }
}

void show()
{
    if(cost[0] == -1){
        printf("We search by end but cannot\n");
    }else{
        printf("%d\n",cost[0]);
    }
}

