#include <queue>
#include <stdio.h>

int map[18][18];
int a,b;

class POSITION{
		public:
				int x,y;
				POSITION & operator=(const POSITION & p)
				{
						if(this == &p)	return *this;
						x=p.x;
						y=p.y;
				}
};

void init()
{
		for(int i=0;i<18;i++){
				for(int j=0;j<18;j++){
						map[i][j] = -1;
				}
		}

		FILE *ifp = fopen("input.txt","r");
		fscanf(ifp,"%d %d",&a,&b);
		printf("a , b = %d , %d\n",a,b);
		for(int i=1;i<=a;i++){
				for(int j=1;j<=b;j++){
						map[i][j] = 0;
				}
		}

		int n,x,y;
		fscanf(ifp,"%d",&n);
		for(int i=0;i<n;i++){
				fscanf(ifp,"%d %d",&x,&y);
				map[x][y] = -1;
		}

		map[1][1] = 1;

		fclose(ifp);
}

void filllist()
{
		std::queue<POSITION> next;
		POSITION p,q,r;

		p.x=1;p.y=1;
		next.push(p);
		while(!next.empty()){
				p = next.front(); 
				next.pop();

				if(map[p.x][p.y] == -1)
						continue;

				if(map[p.x+1][p.y] != -1){
						map[p.x+1][p.y] += map[p.x][p.y];
						q.x = p.x+1; q.y = p.y;
						next.push(q);
				}
				if(map[p.x][p.y+1] != -1){
						map[p.x][p.y+1] += map[p.x][p.y];
						r.x = p.x;	r.y = p.y+1;
						next.push(r);
				}

				if(p.x != a || p.y != b)
						map[p.x][p.y] = -1;
		}
}

void show()
{
		printf("%d\n",map[a][b]);
}

int main()
{
		init();

		filllist();

		show();
}
