#include <stdio.h>

int date[11] = {0,21,34,1,9,11,23,90,77,8,6};

void swap(int i,int j)
{
	int k = date[i];
	date[i] = date[j];
	date[j] = k;
}

void heapsort(int last)
{
	for(last;1<last;last--){
		for(int i=last;1<i;i--){
			if(date[i/2]<date[i])
				swap(i/2,i);
		}
		swap(1,last);
	}
}

int main()
{
	for(int i=1;i<=10;i++)
		printf("%d\n",date[i]);
	
	heapsort(10);
	
	printf("-----------\n");
	
	for(int i=1;i<=10;i++)
		printf("%d\n",date[i]);
}
