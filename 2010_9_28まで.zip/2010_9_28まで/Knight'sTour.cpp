#include <iostream>

int result[10][10];

int tour(int map[10][10],int x,int y)
{
		for(int i=1+OFFSET;i<=6+OFFSET;i++){
				for(int i=1+OFFSET;i<=6+OFFSET;i++){
						if(map[i][j] <= 0)
								goto notend;
				}
		}
		for(int i=0;i<10;i++){
				for(int j=0;j<10;j++){
						result[i][j]=map[i][j];
				}
		}
		return 0;
notend:
		if(map 
