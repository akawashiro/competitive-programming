#include <stdio.h>
#include <stdlib.h>

char square[100][100];

void makewhirl(int n,int x,int y)
{
    if(4<n){
        
        square[x+2][y+1] = '#';
        for(int i=0;i<n;i++)
            square[x][y+i] = '#';
        for(int i=0;i<n;i++)
            square[x+i][y+n-1] = '#';
        for(int i=0;i<n;i++)
            square[x+n-1][y+i] = '#';
        for(int i=0;i<n-2;i++)
            square[x+2+i][y] = '#';
        makewhirl(n-4,x+2,y+2);
    }
    else if(n==4){
        for(int i=0;i<n;i++)
            square[x][y+i] = '#';
        for(int i=0;i<n;i++)
            square[x+i][y+n-1] = '#';
        for(int i=0;i<n;i++)
            square[x+n-1][y+i] = '#';
        for(int i=0;i<n-2;i++)
            square[x+2+i][y] = '#';
    }
    else if(n==3){
        for(int i=0;i<n;i++)
            square[x][y+i] = '#';
        for(int i=0;i<n;i++)
            square[x+i][y+n-1] = '#';
        for(int i=0;i<n;i++)
            square[x+n-1][y+i] = '#';
    }
    else if(n==2){
        for(int i=0;i<n;i++)
            square[x][y+i] = '#';
        for(int i=0;i<n;i++)
            square[x+i][y+n-1] = '#';
    }
    else if(n==1){
        square[x][y] = '#';
    }
}

int main(int argc, char *argv[])
{
    int n = atoi(argv[1]);
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            square[i][j] = ' ';
    makewhirl(n,0,0);
    for(int j=n-1;0<=j;j--){
        for(int i=0;i<n;i++){
            printf("%c",square[i][j]);
        }
        printf("\n");
    }
}
